// JavaScript source code
function ValidateListing()
{
    this.initialize = function ()
    {
        alert('initialize');
        //var nameIsValid = ValidateListingName();
        //if(nameIsValid)
        //{
        //    var logoIsValid = ValidateImage();
        //    if(logoIsValid)
        //    {
        //        return true;
        //    }
        //}
    }



}
